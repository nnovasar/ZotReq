function displayUsers() {
	//console.log("displayUsers...");
	let course_name = $("#course").val();
	course_name = course_name.toUpperCase();
	//console.log(course_name);
	let url = `http://localhost:3000/users`;
	fetch(url + `/${course_name}`)
		.then(response => {
			return response.json();
		})
		.then(response => {
			display(response);
		})
		.catch(error => console.log(error));
		$("#user-holder").empty();
		let result = "Sorry, couldn't find the class. Try again."
		const foo = `<ul class='center-align'>${result}</ul>`;
		$("#user-holder").append(foo);

}

function handle(e){
	if (e.keyCode == 13){
		displayUsers();
	}
}

function display(userArray) { // value; whole prereq list for course
	let result = "";
	let controlSet = new Set();
	let len = userArray.length; // num conditionals
	for (let counter = 0; counter < len; ++counter) { // counter
		let littleLen = userArray[counter].length; // length of inner array
		let content = "";
		let i = 0;
		if (littleLen == 1) { // nest only 1: not an or, 
			console.log(userArray[counter]);
			if (!controlSet.has(userArray[counter][0])) {
				content += `<li class='collection-item amber lighten-4'>${userArray[counter][0][0]}`;
			} else {
				controlSet.add(userArray[counter][0]);
			}
			if (userArray[counter][0].length > 1){
				content += `  (Min Grade: ${userArray[counter][0][1]})`;
			}
			//content += `</li>`;
			
		} else { // is an or
	
			for (; i < littleLen; ++i) {
				if (!controlSet.has(userArray[counter][i][0])) {
					if (userArray[counter][i].length == 1){
						content += `<li class='collection-item light-blue lighten-3'>${userArray[counter][i]}`;
					} else {
						content += `<li class='collection-item light-blue lighten-3'>${userArray[counter][i][0]}`;
					}
                    if (userArray[counter][i].length == 2){
                        content += `  (Min Grade: ${userArray[counter][i][1]})`;
                    }
                    
				} else {
					controlSet.add(userArray[counter][i][0]);
				}
				if(i < littleLen-1) { content += `<li class='col12  light-blue lighten-5'>OR</li>`; }
			}
		}
		content += `</li>`;
		if (counter + 1 < len) content += `<li class='collection-item teal lighten-2'>AND</li>`;
		result += content;
	}
	$("#user-holder").empty();
	const foo = `<ul class='collection center-align'>${result}</ul>`;
	$("#user-holder").append(foo);
}
