function displayUsers() {
	//console.log("displayUsers...");
	let course_name = $("#course").val();
	course_name = course_name.toUpperCase();
	//console.log(course_name);
	let url = `http://localhost:3000/users`;
	fetch(url + `/${course_name}`)
		.then(response => {
			return response.json();
		})
		.then(response => {
			display(response);
		})
		.catch(error => console.log(error));
		$("#user-holder").empty();
		let result = "Sorry, couldn't find the class. Try again."
		const foo = `<ul class='center-align'>${result}</ul>`;
		$("#user-holder").append(foo);

}

function handle(e){
	if (e.keyCode == 13){
		displayUsers();
	}
}

function display(userArray) { // value; whole prereq list for course
	let result = `<div class = "row">`;
	let controlSet = new Set();
	let len = userArray.length; // num conditionals
	for (let counter = 0; counter < len; ++counter) { // counter
		let littleLen = userArray[counter].length; // length of inner array
		let content = "";
		let i = 0;
		if (littleLen == 1) { // nest only 1: not an or, 
			//console.log(userArray[counter]);
			//content += `<div class = "row">`;
			if (!controlSet.has(userArray[counter][0])) {
				content += `<div class='col s12 amber lighten-4'>${userArray[counter][0][0]}`;
				
				if (userArray[counter][0].length > 1){
					content += `   (Min Grade: ${userArray[counter][0][1]})</div>`;
				} else {
					content += `</div>`;
				}

			} else {
				controlSet.add(userArray[counter][0]);
			}
			//content += `</div>`;
			
		} else { // is an or
			//content += `<div class = "row">`;
			let blcs = 0;
			let sz = 12 /// (userArray[counter].length + 1);
			if (sz < 4) { sz = 12};
			//console.log(userArray[counter]);
			let first = false;;
			console.log(sz);
			for (; i < littleLen; ++i) {
				//if (first){ sz = 12; first = false;}
				if (!controlSet.has(userArray[counter][i][0])) {
					if (userArray[counter][i].length == 1){
						content += `<div class='col s${sz} light-blue lighten-3'>${userArray[counter][i]}`;
					} else {
						content += `<div class='col s${sz} light-blue lighten-3'>${userArray[counter][i][0]}`;
					}
                    if (userArray[counter][i].length == 2){
						content += `   (Min Grade: ${userArray[counter][i][1]})`;
						first = true;
                    }
					++blcs;
					
						
					content += `</div>`;
						
					/*if (blcs >= 3 && sz != 12){
						//content += `</div>`;
						blcs = 0;
						sz = 6;
					}*/
					if(i < littleLen-1) { 
						if (first && sz != 12){ content += `<div class='col s${sz}  light-blue lighten-5 center-align'><br/>OR</div>`; }
						else { content += `<div class='col s${sz}  light-blue lighten-5 center-align'>OR</div>`; ++blcs; }
					}

				} else {
					controlSet.add(userArray[counter][i][0]);
				}
			}
			//content += `</div>`
		}
		//content += `</li>`;
		if (counter + 1 < len) content += `<div class='col s12 teal lighten-2'>AND</div>`;
		//content += `</div>`;
		//content += `</div>`;
		result += content;
		
	
	}
	result += `</div>`;
	$("#user-holder").empty();
	const foo = `${result}`;//`<ul class='collection center-align'>${result}</ul>`;
	$("#user-holder").append(foo);
}
