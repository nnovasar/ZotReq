function displayUsers() {
	console.log("displayUsers...");
	let course_name = $("#course").val();
	console.log(course_name);
	let url = `http://localhost:3000/users`;
	fetch(url + `/${course_name}`)
		.then(response => {
			return response.json();
		})
		.then(response => {
			display(response);
		})
		.catch(error => console.log(error));
}

function display(userArray) {
	let result = "";
	let controlSet = new Set();
	let len = userArray.length;
	for (let counter = 0; counter < len; ++counter) {
		let littleLen = userArray[counter].length;
		let content = "";
		if (littleLen == 1) {
			if (!controlSet.has(userArray[counter][0])) {
				//console.log(userArray[counter][0]);
				console.log(userArray[counter]);
				content += `<li class='collection-item grey darken-3'>${userArray[counter][0]} Grade: ${userArray[counter][1]}</li>`;
			} else {
				controlSet.add(userArray[counter][0]);
			}
		} else {
			let i = 0;
			for (; i < littleLen; ++i) {
				if (!controlSet.has(userArray[counter][i][0])) {
					content += `<li class='collection-item light-blue'>${userArray[counter][i][0]} Grade: ${userArray[counter][i][1]}</li>`;
				} else {
					controlSet.add(userArray[counter][i][0]);
				}
			}
			if (counter + 1 < len) content += `<p class='text-white'>AND</p>`;
		}
		result += content;
	}
	$("#user-holder").empty();
	const foo = `<ul class='collection center-align'>${result}</ul>`;
	$("#user-holder").append(foo);
}
