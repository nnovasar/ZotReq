const request = require("request");
const express = require("express");
const app = express();
const port = 3000;

app.all("/*", function(req, res, next) {
	res.header("Access-Control-Allow-Origin", "*");
	res.header("Access-Control-Allow-Headers", "X-Requested-With");
	next();
});

app.get("/", (req, res) => {
	res.send("Hello!");
});
app.get("/users/:course", (req, res) => {
	console.log("Receive get user request");
	console.log(req.params.course);
	getUsers(res, req.params.course);
});

/**
 * @function getUsers - simulates a backend calling a database to get list of
 * users which then gets returned to the frontend that calls through the default
 * route
 * @param {@} res
 */
function getUsers(res, course) {
	const fs = require("fs");
	const raw_data = fs.readFileSync("data.json");
	const data = JSON.parse(raw_data);
	var map = new Map();

	Object.keys(data).forEach(key => {
		map[key] = data[key];
	});

	Object.keys(map).forEach(key => {
		if (key == course) res.send(map[key]);
	});
	// request("https://n161.tech/api/dummyapi/user", function(
	// 	error,
	// 	response,
	// 	body
	// ) {
	// 	res.send(body);
	// });
}

app.listen(port, () =>
	console.log(`Backend server listening on port ${port}!`)
);
